from django.apps import AppConfig


class FakenewsConfig(AppConfig):
    name = 'fakenews'
