# Libraries
from django.shortcuts import render,redirect
from django.http import HttpResponse

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
import itertools
from sklearn.naive_bayes import MultinomialNB
from sklearn import metrics
from sklearn.linear_model import PassiveAggressiveClassifier
import os

import seaborn as sns
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory
from fakenews.models import User

################ Home #################
def home(request):
	return render(request,'home1.html')
def login(request):
	return render(request,'loginform.html')
def loginCheck(request):
	if request.method == 'POST':
		firstname = request.POST.get('username')
		password = request.POST.get('email')
		request.session['firstname'] = firstname 
		print(firstname)
		print(password)
		user_object=User.objects.get(firstname=firstname,password=password)
		print('--------------------')
		print(user_object)
		try:
			print('hi')
			user_object=User.objects.get(firstname=firstname,password=password)
			print(user_object)
			if user_object is not None:
				print('hiiiiiiii')
				request.session['useremail'] = user_object.email
				return redirect('home')
		except:
			#user_object = None
			print('hello')
			return redirect('login')
	return render(request,'home.html')	
def logout(request):
	return render(request,'index.html')	
def reg(request):
	return render(request,'register.html')

######## SVM ######
def save(request):
	if request.method == 'POST':
		print('printtttttttttttttttttttttttttttttttt')
		print('checkkkkkkkkkkkkkkkkk')
		username= request.POST.get('username')
		password= request.POST.get('password')
		address= request.POST.get('address')
		email= request.POST.get('email')
		age= request.POST.get('age')
		gender= request.POST.get('gender')
		phone= request.POST.get('phone')
		user=User()
		user.firstname= request.POST.get('username')
		user.password= request.POST.get('password')
		user.address= request.POST.get('address')
		user.email= request.POST.get('email')
		user.age= request.POST.get('age')
		user.gender= request.POST.get('gender')
		user.phone= request.POST.get('phone')
		user.save()		
		return render(request,'loginform.html')
	return render(request,'loginform.html')	


######## SVM ######
def nvb(request):
	return render(request,'pacweb1.html')
def pac(request):				 
	return render(request,'result.html')
def svm(request):	
	return render(request,'acc1.html')		
def dec(request):

	return render(request,'acc1.html')
def randomf(request):
	return render(request,'acc1.html')
def mnb(request):
	return render(request,'acc1.html')
def graph(request):
	if request.method == 'POST' and request.FILES['myfile']:
		# Importing libraries
		import os
		import pandas as pd
		import numpy as np
		import matplotlib.pyplot as plt
		from matplotlib.image import imread
		import seaborn as sns
		import random
		from PIL import Image
		from sklearn.model_selection import	 train_test_split
		from tensorflow.keras.utils import to_categorical
		import tensorflow as tf
		from tensorflow.keras.models import Sequential, model_from_json
		from tensorflow.keras.layers import Dense, Flatten, Dropout, Conv2D, MaxPool2D
		myfile = request.FILES['myfile']
		file1=myfile.name
		######
		
		
		##########################
		
		
		################################
		import sys,os
		print('*******************************************************************')
		print(os.path.join(os.getcwd(), 'img', file1))
		print('*******************************************************************')
		import os
		dirname = os.path.dirname(__file__)
		filename = os.path.join(dirname, myfile.name)
		print(filename)
		global model
		from keras.models import model_from_json

		dim1 = []
		dim2 = []

		for i in range(0,2):
			labels = 'E:/2022projects/skin_disease/images' + '/{0}'.format(i)
			image_path = os.listdir(labels)
			for x in image_path:
				img = imread(labels + '/' + x)
				dim1.append(img.shape[0])
				dim2.append(img.shape[1])

		print("Dimension 1 Mean : ",np.mean(dim1), " Dimension 2 Mean : ",np.mean(dim2))

		images = []
		label_id = []

		for i in range(2):
			labels = 'E:/2022projects/skin_disease/images' + '/{0}'.format(i)
			image_path = os.listdir(labels)
			for x in image_path:
				img = Image.open(labels + '/' + x)
				img = img.resize((50,50))
				img = np.array(img)
				images.append(img)
				label_id.append(i)

		images = np.array(images)

		images = images/255


		label_id = np.array(label_id)
		label_id.shape

		images.shape


		label_counts = pd.DataFrame(label_id).value_counts()
		label_counts.head()

		x_train, x_val, y_train, y_val = train_test_split(images, label_id , test_size = 0.2, random_state = 42)

		y_train_cat = to_categorical(y_train)
		y_val_cat = to_categorical(y_val)


		model = Sequential()

		model.add(Conv2D(filters = 64, kernel_size = (3,3), input_shape = x_train.shape[1:], activation = 'relu', padding = 'same'))
		model.add(MaxPool2D(pool_size=(2,2)))
		model.add(Dropout(0.5))

		model.add(Conv2D(filters = 64, kernel_size = (3,3), activation = 'relu'))
		model.add(MaxPool2D(pool_size=(2,2)))
		model.add(Dropout(0.5))

		model.add(Flatten())
		model.add(Dense(128, activation = 'relu'))
		model.add(Dropout(0.5))
		model.add(Dense(2, activation = 'softmax'))

		model.compile(loss = 'sparse_categorical_crossentropy', optimizer = 'adam', metrics = ['accuracy'])
		model.summary()


		model.fit(x_train, y_train, epochs = 50, batch_size = 128, validation_data = (x_val, y_val), verbose = 2)

		model_json = model.to_json()



		test_path1 = 'E:/2022projects/skin_disease/test_images/'+file1
		img = Image.open(test_path1)
		img = img.resize((50,50))
		img = np.array(img)
		im2arr = img.reshape(1,50,50,3)
		test = np.asarray(im2arr)
		test = test.astype('float32')
		test = test/255


		all_lables = ['benign','malignant']


		y_pred1 = model.predict_classes(test);
		print(y_pred1)

		testimg_path="E:/2022projects/skin_disease/test_images/"+file1

		if y_pred1==0:
			import cv2
			from imutils import paths
			import imutils
			imagedisplay = cv2.imread(test_path1)
			orig = imagedisplay.copy()
			output = imutils.resize(orig, width=400)
			cv2.putText(output, "benign", (10, 25),	cv2.FONT_HERSHEY_SIMPLEX,0.7, (0, 255, 0), 2)
			cv2.imshow("Predicted Image Result", output)
			cv2.waitKey(0)
			return render(request, 'home1.html')
		elif y_pred1==1:
			import cv2
			from imutils import paths
			import imutils
			imagedisplay = cv2.imread(test_path1)
			orig = imagedisplay.copy()
			output = imutils.resize(orig, width=400)
			cv2.putText(output, "malignant", (10, 25),	 cv2.FONT_HERSHEY_SIMPLEX,0.7, (0, 255, 0), 2)
			cv2.imshow("Predicted Image Result", output)
			cv2.waitKey(0)
			return render(request, 'home1.html')
	return render(request,'home1.html')
def accuracy(request):
	return render(request,'index.html')
			